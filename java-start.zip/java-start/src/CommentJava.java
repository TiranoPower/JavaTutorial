// 2024.10.03
public class CommentJava {
    public static void main(String[] args) { // psvm = public static void main...
        System.out.println("hello java1"); // sout = System.out.println();
        // System.out.println();
        /*
        System.out.println("hello java3");
        System.out.println("hello java4");
        // -> 한줄 주석
        /* 전체 주석
         */

    }
}
