// 2024.10.03
public class HelloJava { // class
    public static void main (String[] args) { // method, 프로그램 시작점
        System.out.println("hello java"); // 값 콘솔 출력
    }
}
