// 2024.10.03
package variable;

public class Var8 {
    public static void main(String[] args) {
        // 정수 (int를 기본으로 씀)
        byte b = 127; // -128 ~ 127
        short s = 32767; // -32,768 ~ 32,767
        int i = 2147483647; // -2,147,483,648 ~ 2,147,483,647 (약 20억)



        // -9,223,372,036,854,775,808 ~ 9,223,372,036,854,775,807
        long l = 9223372036854775807L ; // 대문자 L -> 소문자 l로 바꾸면 1처럼 보이기 때문에 권장X

        // 실수 (범위 -> float < double)
        // double을 보통으로 씀
        float f = 10.0f;
        double d = 10.0;

        /* 자주 사용 하는 것
           정수 : int, long(20억 넘을 때)
           실수 : double
           불린형 : bollean
           문자열 : String
         */

        /*
            낙타표기법(camel case)
            변수 : order detail -> orderDetail(첫번째 문자는 소문자) -> 변수이름은 잘 지어야됨.
            클래스 : 첫번째 문자 대문자, 이어지면 낙타 표기법 ex) OrderMine
            예외 : 상수는 모두 대문자 사용, 언더바로 구분 ex) USER_LIMIT (뒤에서 배움)
            패키지 : 모두 소문자 사용 ex) org.spring.boot (뒤에서 배움)


         */

    }
}
