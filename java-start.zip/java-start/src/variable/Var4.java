// 2024.10.03
package variable;

public class Var4 {
    public static void main(String[] args) {
        int a;
        int b;
        int c,d; // 변수 여러개도 선언 가능
    }
}
