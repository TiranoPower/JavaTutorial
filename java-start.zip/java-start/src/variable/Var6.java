package variable;

public class Var6 {
    public static void main(String[] args) {
        int a;
       // System.out.println(a);
        /*
            java: variable a might not have been initialized -> 변수 선언(값 지정이)이 안됬다,
            java에서는 이상한 값이 출력될 수 있기때문에 강제함.
            참고 : 지역변수는 개발자가 직접 초기화
            컴파일 에러 : java:6:28 6번째 라인, 28번째 글자 오류

        */

    }
}
