// 2024.10.03
package variable;

public class Var2 {
    public static void main(String[] args) {
        int a; // 변수 선언
        a = 20; // 10 -> 20 , 변수 초기화
        // 오른쪽 값을 왼쪽에 저장한다는 뜻

        System.out.println(a);
        System.out.println(a);
        System.out.println(a);
    }
}
