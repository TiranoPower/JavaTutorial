// 2024.10.03
package variable;

public class Var3 {
    public static void main(String[] args) {
        int a; // 변수 선언(숫자, 정수)
        a = 10; // 변수 초기화
        System.out.println(a);
        a = 50; // 변수 값 변경 : a(10 -> 50)
        System.out.println(a);
        // 변수의 값을 변경하면 변수에 들어있던 기존 값은 삭제된다.
    }
}
